---
name: diagnose
description: |
  Run diagnostics for the AlgVex trading system. 运行 AlgVex 交易系统诊断。

  Use this skill when:
  - No trading signals are being generated (没有交易信号)
  - Need to check if AI analysis is working (检查 AI 分析是否正常)
  - Verifying technical indicator calculations (验证技术指标计算)
  - Debugging market data fetching issues (调试市场数据获取)
  - Troubleshooting why no trades are happening (排查为什么没有交易)
  - Running system health checks (运行系统健康检查)

  Keywords: diagnose, debug, signals, indicators, AI, analysis, troubleshoot, 诊断, 调试, 信号
---

# Trading System Diagnostics

## Purpose

Use this skill when:
- No trading signals are being generated
- Need to verify AI analysis is working
- Validating technical indicator calculations
- Debugging market data issues

## Diagnostic Commands

### Full Diagnostic (Default)
```bash
cd /home/linuxuser/nautilus_AlgVex
source venv/bin/activate
python3 scripts/diagnose.py
```

### Quick Diagnostic (Skip AI calls)
```bash
cd /home/linuxuser/nautilus_AlgVex
source venv/bin/activate
python3 scripts/diagnose.py --quick
```

### With Update and Restart
```bash
python3 scripts/diagnose.py --update --restart
```

## Expected Output

### Normal Operation Signs
```
✅ Configuration loaded successfully
✅ Market data fetched successfully
✅ TechnicalIndicatorManager initialized
✅ Technical data retrieved
✅ Sentiment data retrieved
✅ MultiAgent 层级决策成功
   🐂 Bull Agent 分析中...
   🐻 Bear Agent 分析中...
   ⚖️ Judge Agent 判断中...
   🛡️ Risk Manager 评估中...
🎯 Judge 最终决策: BUY/SELL/HOLD
```

### Key Checkpoints

| Check | Normal Value | Abnormal Handling |
|-------|--------------|-------------------|
| RSI | 0-100 | Out of range = data error |
| MACD | Any value | NaN = insufficient data |
| Judge Signal | BUY/SELL/HOLD | ERROR = API failure |
| Winning Side | BULL/BEAR/TIE | 显示辩论胜方 |

## 信号决策流程 (层级决策架构)

采用 TradingAgents 层级决策架构，Judge 决策即最终决策

```
决策流程:
Phase 1: Bull/Bear Debate (辩论)
  └→ 🐂 Bull Agent: 寻找做多理由
  └→ 🐻 Bear Agent: 寻找做空理由

Phase 2: Judge (Portfolio Manager) Decision
  └→ ⚖️ 评估辩论结果，做出最终决策

Phase 3: Risk Evaluation
  └→ 🛡️ 确定仓位大小和止损止盈
```

**注意**: 所有策略参数配置在 `configs/base.yaml` 中管理。

## Common Issues

### 1. No Trading Signals

**Possible Causes**:
- Judge returns HOLD (Bull/Bear辩论无明显胜者)
- Confidence below min_confidence_to_trade
- Risk Manager 认为风险过高

**Check Command**:
```bash
python3 scripts/diagnose_realtime.py 2>&1 | grep -E "(Judge|Final Signal|Confidence|Winning Side)"
```

### 2. DeepSeek API Failure

**Check**:
```bash
grep "DEEPSEEK_API_KEY" ~/.env.algvex
```

### 3. Abnormal Technical Indicators

**Check**:
```bash
python3 scripts/diagnose.py 2>&1 | grep -E "(RSI|MACD|SMA)"
```

## Key Files

| File | Purpose |
|------|---------|
| `scripts/diagnose.py` | Main diagnostic script |
| `scripts/diagnose_realtime.py` | Real-time API diagnostic |
| `scripts/diagnostics/` | Modular diagnostic system |
| `scripts/smart_commit_analyzer.py` | Regression detection (auto-evolving rules) |
| `strategy/ai_strategy.py` | Main strategy logic |
| `configs/base.yaml` | Base configuration (all parameters) |
| `configs/production.yaml` | Production environment overrides |

## Order Flow Simulation (v3.18)

模块化诊断系统包含 7 个订单流场景模拟。

### 7 Scenarios (模拟场景)

| 场景 | 描述 | 测试目标 |
|------|------|----------|
| **1. New Position** | 开新仓 (无现有持仓) | Bracket 订单创建 |
| **2. Add to Position** | 加仓 (同方向) | SL/TP 数量更新 |
| **3. Reduce Position** | 减仓 | SL/TP 数量减少 |
| **4. Reversal** | 反转仓位 (多→空/空→多) | 两阶段提交逻辑 |
| **5. Close Position** | 平仓信号 | 仓位关闭 + 取消 SL/TP |
| **6. Bracket Failure** | SL/TP 订单失败 | CRITICAL 告警 (不回退) |
| **7. SL/TP Modify Failure** | SL/TP 修改失败 | WARNING 告警 |

### Run Order Flow Simulation

```bash
cd /home/linuxuser/nautilus_AlgVex
source venv/bin/activate
python3 scripts/diagnose_realtime.py
```

诊断输出将包含 "Step 9: Order Flow Simulation (v3.18)" 显示所有 7 个场景的模拟结果。

### Expected Output

```
============================================================
Step 9: Order Flow Simulation (v3.18)
============================================================
✅ Scenario 1: New Position - PASSED
✅ Scenario 2: Add to Position - PASSED
✅ Scenario 3: Reduce Position - PASSED
✅ Scenario 4: Reversal - PASSED
✅ Scenario 5: Close Position - PASSED
✅ Scenario 6: Bracket Failure - PASSED
✅ Scenario 7: SL/TP Modify Failure - PASSED

📊 Order Flow Simulation Summary: 7/7 scenarios passed
```

## 回归检测 (修改代码后必须运行)

```bash
# 智能回归检测 (规则自动从 git 历史生成)
python3 scripts/smart_commit_analyzer.py

# 预期结果: ✅ 所有规则验证通过
```
